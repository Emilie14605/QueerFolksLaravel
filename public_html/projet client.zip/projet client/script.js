const img = document.getElementsByClassName('image-bubble');
const imagearray = Array.from(img);
const dialog = document.getElementById('popup');
const popupImg = document.getElementById('popup__img');
const bubble = document.getElementById('bubble');

imagearray.forEach(function (imgEl) {
    imgEl.addEventListener('click', function (e) {
        const {src} = e.target.attributes
        const {image} = e.target.dataset
        console.log({image});

        if (typeof dialog.showModal === "function") {
            dialog.showModal();
            popupImg.setAttribute('src', `photoprojet/${image}`);
          } else {
            console.error("L'API <dialog> n'est pas prise en charge par ce navigateur.");
          }
    })
    imgEl.addEventListener('mouseenter', function (e) {
        const {value} = e.target.attributes.alt
        const {clientWidth, clientHeight} = e.target;
        bubble.style.display = "block";
        bubble.style.left = (e.target.offsetLeft + (clientWidth / 3 * 2)) + "px";
        bubble.style.top = (e.target.offsetTop - (bubble.clientHeight / 3)) + "px";
        console.log(e.target.offsetTop, e.target.offsetLeft, clientWidth, clientHeight);
    })
    imgEl.addEventListener('mouseleave', function (e) {
        const {value} = e.target.attributes.alt
        bubble.style.display = "none";
    })
    bubble.addEventListener('mouseenter', function (e) {
        bubble.style.display = "block";
    })
        bubble.addEventListener('mouseleave', function (e) {
        bubble.style.display = "none";
    })
})


// Partie carousel

let carouselIndex = 0;
const carouselIndexMax = 2;
const li = Array.from(document.getElementsByClassName('nav-slider__number'));
const carouselImg = Array.from(document.getElementsByClassName('image-header__img'));
const flecheHaut = document.getElementById('fleche');
const flecheBas = document.getElementById('fleche-bas');

let interval = setInterval(incrementIndex, 3000);

function incrementIndex() {
    if(carouselIndex < carouselIndexMax)
    {
        carouselIndex++;
    } else {
        carouselIndex = 0;
    }
    changeSlide();
}

flecheBas.addEventListener('click', function() {
    console.log(carouselIndex);
    if(carouselIndex < carouselIndexMax)
    {
        carouselIndex++;
    } else {
        carouselIndex = 0;
    }
    clearInterval(interval);
    interval = setInterval(incrementIndex, 3000);
    changeSlide();
})

flecheHaut.addEventListener('click', function () {
    console.log(carouselIndex);
    if(carouselIndex > 0)
    {
        carouselIndex--;
    } else {
        carouselIndex = carouselIndexMax;
    }
    clearInterval(interval);
    interval = setInterval(incrementIndex, 3000);
    changeSlide();
})

function changeSlide(){
    li.forEach(function (el, i) {
        if(i === carouselIndex)
        {
            el.classList.add('active');
        } else {
            el.classList.remove('active');
        }
    })
    carouselImg.forEach(function (el, i) {
        if(i === carouselIndex)
        {
            el.style.zIndex = carouselIndex - 10;
            el.classList.add('active');
        } else {
            el.style.zIndex = -10;
            el.classList.remove('active');
        }
    })
}
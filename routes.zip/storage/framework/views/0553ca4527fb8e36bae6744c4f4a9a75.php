<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/index.css']); ?>

<section class="container">

    <h1>Queer&Folks</h1>
    <p>Bienvenue sur Queer&folks, un site de rencontre spécialement fait pour les membres de la communauté LGBTQIA+, ici vous pourrez trouver des personnes recherchant la même chose que vous, que ça soit une rencontre d'un soir, plus longue ou simplement une amitié</p>
    <p>Pour accéder au site, vous pouvez vous créer un compte <a href="<?php echo e(route('register')); ?>">ici</a></p>
    <p>Si vous êtes déjà membre, connectez vous <a href="<?php echo e(route('login')); ?>">ici</a></p>
    <img src="<?php echo e(asset('images/front-page-image.jpg')); ?>" alt="">

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/index.blade.php ENDPATH**/ ?>
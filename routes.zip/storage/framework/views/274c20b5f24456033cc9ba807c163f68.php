<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/parameters.css', 'resources/js/app.js']); ?>

<a href="<?php echo e(route('login')); ?>">Click</a>
<div class="param">
    <form action="<?php echo e(route('profileupdate')); ?>" method="post" enctype="multipart/form-data" name="updateform">
    <?php echo method_field('PUT'); ?>
    <?php echo csrf_field(); ?>
        <label for="name">Nom :</label>
        <input type="text" name="name" id="name" value="<?php echo e(old('name')); ?>">
        <label for="email">Email :</label>
        <input type="text" name="email" id="email" value="<?php echo e(old('email')); ?>">
        <label for="password">Mot de passe :</label>
        <input type="password" name="password" id="password" value="<?php echo e(old('password')); ?>">
        <label for="passwordr">Répéter votre mot de passe</label>
        <input type="password" name="passwordr" id="passwordr" value="<?php echo e(old('passwordr')); ?>">
        <label for="firstname">Prénom</label>
        <input type="text" name="firstname" id="firstname" value="<?php echo e(old('firstname')); ?>">
        <label for="surname">Pseudo</label>
        <input type="text" name="surname" id="surname" value="<?php echo e(old('surname')); ?>">
        <label for="age">Age</label>
        <input type="number" name="age" id="age" value="<?php echo e(old('age')); ?>">
        <label for="picture">Photo de profil</label>
        <input type="file" name="picture" id="picture" value="<?php echo e(old('picture')); ?>">
        <label for="description"></label>
        <textarea name="description" id="description"></textarea>
        <select name="gender" id="gender">
            <option value="">Sélectionnez un genre</option>
            <option value="Homme Cisgenre" <?php echo e(old('gender') === 'Homme Cisgenre' ? 'selected' : ''); ?>>Homme Cisgenre</option>
            <option value="Femme Cisgenre" <?php echo e(old('gender') === 'Femme Cisgenre' ? 'selected' : ''); ?>>Femme Cisgenre</option>
            <option value="Homme Transgenre" <?php echo e(old('gender') === 'Homme Transgenre' ? 'selected' : ''); ?>>Homme Transgenre</option>
            <option value="Femme Transgenre" <?php echo e(old('gender') === 'Femme Transgenre' ? 'selected' : ''); ?>>Femme Transgenre</option>
            <option value="Genderfluid" <?php echo e(old('gender') === 'Genderfluid' ? 'selected' : ''); ?>>Genderfluid</option>
            <option value="Genderqueer" <?php echo e(old('gender') === 'Genderqueer' ? 'selected' : ''); ?>>Genderqueer</option>
            <option value="Agenre" <?php echo e(old('gender') === 'Agenre' ? 'selected' : ''); ?>>Agenre</option>
        </select>
        <select name="sexualorientation" id="sexualorientation">
            <option value="">Sélectionnez une orientation sexuelle</option>
            <option value="Homosexuelle" <?php echo e(old('sexualorientation') === 'Homosexuelle' ? 'selected' : ''); ?>>Homosexuelle</option>
            <option value="Bisexuelle" <?php echo e(old('sexualorientation') === 'Bisexuelle' ? 'selected' : ''); ?>>Bisexuelle</option>
            <option value="Pansexuelle" <?php echo e(old('sexualorientation') === 'Pansexuelle' ? 'selected' : ''); ?>>Pansexuelle</option>
            <option value="Demi-sexuelle" <?php echo e(old('sexualorientation') === 'Demi-sexuelle' ? 'selected' : ''); ?>>Demi-sexuelle</option>
            <option value="Asexuelle" <?php echo e(old('sexualorientation') === 'Asexuelle' ? 'selected' : ''); ?>>Asexuelle</option>
            <option value="Heteroxuelle" <?php echo e(old('sexualorientation') === 'Heteroxuelle' ? 'selected' : ''); ?>>Heteroxuelle</option>
        </select>
        <select name="romanticorientation" id="romanticorientation">
            <option value="">Sélectionnez une orientation romantique</option>
            <option value="Homoromantique" <?php echo e(old('romanticorientation') === 'Homoromantique' ? 'selected' : ''); ?>>Homoromantique</option>
            <option value="Biromantique" <?php echo e(old('romanticorientation') === 'Biromantique' ? 'selected' : ''); ?>>Biromantique</option>
            <option value="Panromantique" <?php echo e(old('romanticorientation') === 'Panromantique' ? 'selected' : ''); ?>>Panromantique</option>
            <option value="Demi-romantique" <?php echo e(old('romanticorientation') === 'Demi-romantique' ? 'selected' : ''); ?>>Demi-romantique</option>
            <option value="Aromantique" <?php echo e(old('romanticorientation') === 'Aromantique' ? 'selected' : ''); ?>>Aromantique</option>
            <option value="Heteroromantique" <?php echo e(old('romanticorientation') === 'Heteroromantique' ? 'selected' : ''); ?>>Heteroromantique</option>
        </select>
        <select name="lookingfor" id="lookingfor">
            <option value="">Sélectionnez une orientation romantique</option>
            <option value="Relation Amicale" <?php echo e(old('lookingfor') === 'Relation Amicale' ? 'selected' : ''); ?>>Relation Amicale</option>
            <option value="Relation Romantique" <?php echo e(old('lookingfor') === 'Relation Romantique' ? 'selected' : ''); ?>>Relation Romantique</option>
            <option value="Relation Sexuelle" <?php echo e(old('lookingfor') === 'Relation Sexuelle' ? 'selected' : ''); ?>>Relation Sexuelle</option>
        </select>
        <button type="reset" name="reset">Annuler</button>
        <a href="<?php echo e(route('register')); ?>">Déjà membre ? Connectez vous</a>
        <button type="submit" name="submit">Enregistrer les modifications</button>
    </form>
    <form action="<?php echo e(route('profile.destroy')); ?>" method="post">
        <?php echo method_field('DELETE'); ?>
        <?php echo csrf_field(); ?>
        <!-- <div class="form-group">
            <label for="passwordd">Mot de passe</label>
            <input type="password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="passwordd" name="passwordd" required>
            <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="invalid"><?php echo e($message); ?></div>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div> -->
        <button type="submit">Supprimer le Compte</button>
    </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/parameters.blade.php ENDPATH**/ ?>
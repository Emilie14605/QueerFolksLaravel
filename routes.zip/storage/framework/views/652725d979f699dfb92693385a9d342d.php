<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <base href="http://localhost/folks/index.php">
    <title>Queer&Folks</title>
</head>

<body>
    <header>
        <img src="<?php echo e(asset('images/menu-burger.svg')); ?>" alt="menu burger" class="icone" id="burger">
        <a href="<?php echo e(route('index')); ?>"><img src="<?php echo e(asset('images/logo.svg')); ?>" alt="Logo" class="icone" id="logo"></a>
        <img src="<?php echo e(asset('images/user.svg')); ?>" alt="Compte" class="icone" id="compte">
    </header>

    <nav class="menu-nav" id="menu">
        <ul>
            <li><a href="<?php echo e(route('index')); ?>">Accueil</a></li>
            <?php if(Auth::check()): ?>
            <li><a href="<?php echo e(route('profile.show', ['id' => Auth::user()->id])); ?>">Profil</a></li>
            <?php endif; ?>
            <li><a href="<?php echo e(route('publications')); ?>">Publications</a></li>
            <li><a href="<?php echo e(route('messages')); ?>">Messages</a></li>
            <li><a href="<?php echo e(route('utlisateurs')); ?>">Page des profils</a></li>
            <li><a href="<?php echo e(route('notif')); ?>">Demandes d'amies</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Me contacter</a></li>
        </ul>
    </nav>

    <?php if(Auth::guest()): ?>
    <div id="popup" class="popup">
        <ul class="popup-content">
            <span class="close">&times;</span>
            <li><a href="<?php echo e(route('register')); ?>">S'inscrire</a></li>
            <li><a href="<?php echo e(route('login')); ?>">Se connecter</a></li>
        </ul>
    </div>
    <?php endif; ?>

    <?php if(Auth::check()): ?>
    <div id="popup" class="popup">
        <ul class="popup-content">
            <span class="close">&times;</span>
            <li><a href="<?php echo e(route('profile.show', ['id' => Auth::user()->id])); ?>">Profil</a></li>
            <li><a href="<?php echo e(route('profile.edit')); ?>">Paramètres</a></li>
            <li>
                <a href="<?php echo e(route('logout')); ?>">Se déconnecter</a>
            </li>
        </ul>
    </div>
    <?php endif; ?>

    <?php echo $__env->yieldContent('content'); ?>
    <footer>
        <ul>
            <li><a href="https://www.patreon.com/user?u=91373358">Me soutenir</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Contact</a></li>
            <li><a href="<?php echo e(route('contact')); ?>">Mention légales</a></li>
            <li><a href="<?php echo e(route('apropos')); ?>">A propos</a></li>
        </ul>
    </footer>
    <script src="js/script.js"></script>
</body>

</html><?php /**PATH C:\laragon\www\queerfolks\resources\views/layouthf.blade.php ENDPATH**/ ?>
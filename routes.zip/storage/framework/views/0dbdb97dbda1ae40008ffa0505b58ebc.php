

<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/messages.css']); ?>

<section class="container">

<h1>Messages envoyés</h1>


<?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<section class="messages" id="messages-sent">
    <p>Message envoyé</p>
    <i><?php echo e($message->created_at); ?></i>
    <a href="<?php echo e(route('messages.details', ['id' => $message->id])); ?>">Voir le message</a>
</section>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/messagessent.blade.php ENDPATH**/ ?>
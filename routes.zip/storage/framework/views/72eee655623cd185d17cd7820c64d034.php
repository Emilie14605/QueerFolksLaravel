<?php echo e($slot); ?>

<?php /**PATH C:\laragon\www\queerfolks\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>
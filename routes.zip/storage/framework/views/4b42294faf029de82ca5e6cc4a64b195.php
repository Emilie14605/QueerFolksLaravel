<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/search.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>

<section>

    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="user">
        <img src="<?php echo e(asset('images/'. $user->id . '/' . $user->picture)); ?>" alt="Photo de profil">
        <h2><?php echo e($user->surname); ?></h2>
        <p><?php echo e($user->gender); ?></p>
        <p><?php echo e($user->sexualorientation); ?></p>
        <p><?php echo e($user->romanticorientation); ?></p>
        <a href="<?php echo e(route('profile.show', ['id' => $user->id])); ?>">Voir plus</a>
        <br>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/search.blade.php ENDPATH**/ ?>
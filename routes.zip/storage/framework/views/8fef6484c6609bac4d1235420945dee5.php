

<?php $__env->startSection('content'); ?>

<form action="" method="post" name="blogs-form">
    <?php echo method_field('POST'); ?>
    <?php echo csrf_field(); ?>
    <label for="title">Titre</label>
    <input type="text" name="title" id="title">
    <label for="content">Contenu</label>
    <textarea name="content" id="content"></textarea>
    <button type="submit" name="submit">Publier</button>
</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/ajoutBlogs.blade.php ENDPATH**/ ?>
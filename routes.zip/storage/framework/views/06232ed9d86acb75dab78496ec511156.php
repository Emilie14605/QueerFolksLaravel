<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/profil.css']); ?>

<h1>Profil</h1>
<section class="container">
    <div class="profile-picture">
        <img src="<?php echo e(asset('images/' . Auth::user()->id . '/' . Auth::user()->picture)); ?>" alt="photo de profil">
    </div>

    <div class="informations">
        <h1><?php echo e($user->surname); ?></h1>

        <p><?php echo e($user->description); ?></p>

        <h2>Sexualité :</h2>
        <?php echo e($user->sexualorientation); ?>


        <h2>Orientation Romantique :</h2>
        <?php echo e($romanticOrientation); ?>


        <h2>Genre :</h2>
        <?php echo e($user->gender); ?>


        <?php if(Auth::id() != $user->id): ?>
        <form action="<?php echo e(route('friendrequest.send')); ?>" method="post">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <input type="hidden" name="sender_id" value="<?php echo e(Auth::id()); ?>">
            <input type="hidden" name="receiver_id" value="<?php echo e($user->id); ?>">
            <input type="hidden" name="status" value="en attente">
            <button type="submit" name="submit">Demander en ami.e</button>
        </form>
        <a href="<?php echo e(route('messages', ['user_id' => $user->id])); ?>">Envoyer un message</a>
        <?php endif; ?>
    </div>

    <div class="publications">
        <div class="blogs">
            <h2>Publications</h2>
            <a href="<?php echo e(route('profile.blog')); ?>">Ajouter une publication</a>
            <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <h2><?php echo e($blog->title); ?></h2><i><?php echo e($blog->created_at); ?></i>
            <br>
            <img src="<?php echo e(asset('images/blogs/'. Auth::user()->id . '/' . $blog->picture)); ?>" alt="">
            <p><?php echo e($blog->content); ?></p>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/profile.blade.php ENDPATH**/ ?>
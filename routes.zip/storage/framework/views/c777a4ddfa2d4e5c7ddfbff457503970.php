<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/blogs.css']); ?>

<section class="container">
    <?php if(Auth::user()->isAdmin): ?>
    <a href="<?php echo e(route('publications.form')); ?>">Faire une nouvelle publication</a>
    <?php endif; ?>
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="blogs">
        <h1><?php echo e($post->title); ?></h1>
        <h3>Auteur.e : <?php echo e($post->author); ?></h3>
        <a href="<?php echo e(route('publications.details', ['id' => $post->id])); ?>">Détails</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/publications.blade.php ENDPATH**/ ?>
<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/blogs.css']); ?>

<section class="container">
    <?php if(Auth::user()->isAdmin): ?>
    <a href="<?php echo e(route('blogsajoutform')); ?>">Ajouter un Blog</a>
    <?php endif; ?>
    <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="blogs">
        <p><?php echo e($blog->title); ?></p>
        <p><?php echo e($blog->author); ?></p>
        <p><?php echo e($blog->content); ?></p>
        <a href="<?php echo e(route('blogsdetails', ['id' => $blog->id])); ?>">Détails</a>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/blogs.blade.php ENDPATH**/ ?>
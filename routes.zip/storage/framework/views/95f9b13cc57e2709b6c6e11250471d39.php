<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/blogs.css']); ?>

<section class="container">
    <h1><?php echo e($blog->title); ?></h1>
    <?php if($blog): ?>
    <div class="blog-detail">
        <p><?php echo e($blog->author); ?></p>
        <img src="<?php echo e(asset('images/blogs/' . Auth::user()->id . '/' . $blog->picture)); ?>" alt="Photo du blog">
        <p><?php echo e($blog->content); ?></p>
        <p><?php echo e($blog->created_at); ?></p>
    </div>
    <?php else: ?>
    <p>Le blog que vous recherchez n'existe pas</p>
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/blogsdetails.blade.php ENDPATH**/ ?>
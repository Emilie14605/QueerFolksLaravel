

<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/messages.css']); ?>

<section class="container">
    <h1>Message</h1>
    <?php if($message): ?>

    <section class="messages">
        <p>Envoyeur.e : <?php echo e($sender->surname); ?></p>
        <p><?php echo e($message->content); ?></p>
    </section>

    <?php endif; ?>
    
    <div class="form">
        <form action="<?php echo e(route('messages.ajout')); ?>" method="POST" name="messages-form">
            <?php echo method_field('POST'); ?>
            <?php echo csrf_field(); ?>
            <select name="receiver" id="receiver">
                <option value="<?php echo e($sender->id); ?>"><?php echo e($sender->surname); ?></option>
            </select>
            <label for="message"></label>
            <textarea name="content" id="content" cols="75" rows="5" placeholder="Message"></textarea>
            <button type="submit" name="submit">Envoyer</button>
        </form>
    </div>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/messages-details.blade.php ENDPATH**/ ?>
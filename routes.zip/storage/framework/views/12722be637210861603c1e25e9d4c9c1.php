<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/notifications.css']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>

<section class="container">
    <h1>Bienvenue sur la page des demandes d'amies</h1>

    <p>Ici vous trouverez toutes les demandes d'amies que les autres utilisateurs vous envoient</p>
    <?php $__currentLoopData = $notifs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notif): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="users">
        <p class="demande">Vous avez une demande d'ami de la part de :
            <a href="<?php echo e(route('profile.show', ['id' => $senders[$notif->sender_id]->id])); ?>"><?php echo e($senders[$notif->sender_id]->surname); ?></a>
            <?php if($notif->status === 'en attente'): ?>
                <form action="<?php echo e(route('notif.add', ['id' => $notif->id])); ?>" method="post">
                    <?php echo method_field('PUT'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="acceptée">
                    <button type="submit" name="submit">✅</button>
                </form>
                <form action="<?php echo e(route('notif.reject', ['id' => $notif->id])); ?>" method="post">
                    <?php echo method_field('POST'); ?>
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="status" value="refusée">
                    <button type="submit" name="submit">❌</button>
                </form>
        <?php endif; ?>
        </p>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/notifications.blade.php ENDPATH**/ ?>
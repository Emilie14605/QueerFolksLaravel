<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/blogs.css']); ?>

<section class="container">
    <h1><?php echo e($post->title); ?></h1>
    <?php if($post): ?>
    <div class="blog-detail">
        <h3>Auteur.e : <?php echo e($post->author); ?></h3>
        <i><?php echo e($date); ?></i>
        <img src="<?php echo e(asset('images/publications/' . $post->post_user_id . '/' . $post->picture)); ?>" alt="Photo du blog">
        <p><?php echo e($post->content); ?></p>
    </div>
    <?php else: ?>
    <p>La publication que vous recherchez n'existe pas</p>
    <?php endif; ?>
</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/publications-details.blade.php ENDPATH**/ ?>
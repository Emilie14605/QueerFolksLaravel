

<?php $__env->startSection('content'); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/css/blogs.css']); ?>


<section class="container">

    <h1>Formulaire d'ajout de blogs</h1>
    <form action="<?php echo e(route('publications.add')); ?>" method="post" name="blogs-form" id="blogs-form" enctype="multipart/form-data">
        <?php echo method_field('POST'); ?>
        <?php echo csrf_field(); ?>
        <label for="title">Titre</label>
        <input type="text" name="title" id="title">
        <label for="picture">Photo</label>
        <input type="file" name="picture" id="picture">
        <label for="content">Contenu</label>
        <textarea name="content" id="content"></textarea>
        <button type="submit" name="submit">Publier</button>
    </form>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/blog-form.blade.php ENDPATH**/ ?>
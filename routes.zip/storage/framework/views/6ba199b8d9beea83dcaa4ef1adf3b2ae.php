

<?php $__env->startSection('content'); ?>

<?php echo app('Illuminate\Foundation\Vite')(['resources/css/style.css', 'resources/js/app.js']); ?>
<?php echo app('Illuminate\Foundation\Vite')(['resources/js/style.js']); ?>

<section class="container">

<form action="<?php echo e(route('image.store')); ?>" method="post" enctype="multipart/form-data">
    <?php echo method_field('POST'); ?>
    <?php echo csrf_field(); ?>
    <label for="image">Image</label>
    <input type="file" name="image" id="image">
    <button type="submit">Enregistrer</button>
</form>

</section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouthf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\queerfolks\resources\views/image-form.blade.php ENDPATH**/ ?>
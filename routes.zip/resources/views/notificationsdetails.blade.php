@extends('layouthf')

@section('content')

@vite(['resources/css/style.css', 'resources/js/app.js'])
@vite(['resources/js/style.js'])


@endsection